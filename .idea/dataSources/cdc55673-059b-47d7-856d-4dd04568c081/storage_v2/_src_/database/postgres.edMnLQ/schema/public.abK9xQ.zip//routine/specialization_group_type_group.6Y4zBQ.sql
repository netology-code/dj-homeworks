create function specialization_group_type_group(date_from date, date_to date)
  returns TABLE(group_id integer, type_id integer, count bigint, total double precision, name character varying, service_name character varying)
language plpgsql
as $$
begin
return query
	select v5.group_id, v5.type_id, v5.count, v5.total, v5.name, v6.service_name from (select * from (select sales_clinicservice.group_id, sales_clinicservice.type_id, sum(v1.count) as count, sum(v1.count*sales_clinicservice.price) as total from (
		select * from sales_paymentservice
		inner join (
			select sales_payment.id as payment_id, sales_payment.creation_time from sales_payment where sales_payment.creation_time >= $1 and sales_payment.creation_time <= $2
			) as v3 on sales_paymentservice.payment_id=v3.payment_id
		) as v1
	inner join sales_clinicservice on v1.service_id = sales_clinicservice.id group by rollup (sales_clinicservice.group_id, sales_clinicservice.type_id)) as v2
	left join sales_servicegroup on v2.group_id = sales_servicegroup.id) as v5
	left join (select sales_service.id, sales_service.code, sales_service.name as service_name from sales_service) as v6 on v5.type_id = v6.id order by (v5.group_id, v5.type_id);
end;
$$;

