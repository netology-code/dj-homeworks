create function administration_service_list(date_from date, date_to date)
  returns TABLE(id integer, count integer, payment_id integer, service_id integer, payment_id_1 integer, creation_time timestamp with time zone, administrator_id integer, appointment_id integer, service_id_1 integer, code character varying, service_name character varying, price double precision, admin_id integer, admin_first_name character varying, admin_last_name character varying, appointment_id_1 integer, patient_id integer, doctor_id integer, patient_id_1 integer, patient_first_name character varying, patient_last_name character varying, doctor_id_1 integer, doctor_first_name character varying, doctor_last_name character varying)
language plpgsql
as $$
begin
return query select * from (select * from (select * from (select * from sales_paymentservice
inner join (select sales_payment.id as payment_id, sales_payment.creation_time, sales_payment.administrator_id, sales_payment.appointment_id from sales_payment where sales_payment.creation_time >= $1 and sales_payment.creation_time <= $2) as v3 on sales_paymentservice.payment_id=v3.payment_id) as v1
inner join (select sales_clinicservice.id as service_id, sales_service.code, sales_service.name as service_name, sales_clinicservice.price from sales_clinicservice inner join sales_service on sales_clinicservice.type_id = sales_service.id)as v4 on v1.service_id=v4.service_id) as v2
inner join (select clinics_clinicuser.id as admin_id, clinics_clinicuser.first_name as admin_first_name, clinics_clinicuser.last_name as admin_last_name from clinics_clinicuser) as v5 on v2.administrator_id = v5.admin_id) as v6
inner join
(select * from (select * from ((select clinics_appointment.id as appointment_id, clinics_appointment.patient_id, clinics_appointment.doctor_id from clinics_appointment) as v7
inner join (select clinics_clinicuser.id as patient_id, clinics_clinicuser.first_name as patient_first_name, clinics_clinicuser.last_name as patient_last_name from clinics_clinicuser) as v8 on v8.patient_id = v7.patient_id) as v9
inner join (select clinics_clinicuser.id as doctor_id, clinics_clinicuser.first_name as doctor_first_name, clinics_clinicuser.last_name as doctor_last_name from clinics_clinicuser) as v10 on v10.doctor_id = v9.doctor_id) as v11) as v12
on v12.appointment_id = v6.appointment_id order by administrator_id, creation_time;
end;
$$;

