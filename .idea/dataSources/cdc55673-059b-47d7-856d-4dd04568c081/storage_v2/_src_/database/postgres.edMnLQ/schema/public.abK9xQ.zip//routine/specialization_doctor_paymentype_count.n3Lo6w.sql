create function specialization_doctor_paymentype_count(date_from date, date_to date)
  returns TABLE(specialization_id integer, doctor_id integer, type smallint, sum bigint, count bigint, spec_id integer, spec_name character varying, id integer, first_name character varying, last_name character varying, middle_name character varying)
language plpgsql
as $$
begin
return query select * from ((select * from ((
	select clinics_clinicdoctor.specialization_id, v1.doctor_id, v1.type, sum(v1.total), count(*) from
	(
		select * from (
			(select * from sales_payment) as payments
			inner join (select clinics_appointment.id as apid, clinics_appointment.doctor_id from clinics_appointment inner join (select * from clinics_appointmenttime where date >= $1 and date <= $2) as ap_time on ap_time.id=clinics_appointment.appointment_time_id)
	as appointments  on appointments.apid=payments.appointment_id)
	) as v1
	inner join clinics_clinicdoctor on v1.doctor_id=clinics_clinicdoctor.user_id group by rollup (clinics_clinicdoctor.specialization_id, v1.doctor_id, v1.type)
) as v2
left join (select clinics_doctorspecialization.id as spec_id, clinics_doctorspecialization.name as spec_name from clinics_doctorspecialization) as v5 on v2.specialization_id =v5.spec_id)) as v3
left join (select clinics_clinicuser.id, clinics_clinicuser.first_name, clinics_clinicuser.last_name, clinics_clinicuser.middle_name from clinics_clinicuser) as v4 on v3.doctor_id = v4.id);
end;
$$;

